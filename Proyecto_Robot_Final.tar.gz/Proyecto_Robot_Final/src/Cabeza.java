public class Cabeza extends Parte_robot{
    Cabeza(int indicador_resistencia){
        super(false, indicador_resistencia);
    }
}